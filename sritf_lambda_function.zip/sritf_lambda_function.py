import json
import boto3

region = 'us-east-1'
ec2 = boto3.resource('ec2')
ec3 = boto3.client('ec2', region_name=region)

def lambda_handler(event, context):
    filters = [
    {
    'Name': 'instance-state-name',
    'Values': ['running']
    }
    ]
    instances = ec2.instances.filter(Filters = filters)
    RunningInstances = []
    for instance in instances:
        RunningInstances.append(instance.id)
#    instanceList = json.dumps(RunningInstances)
    print(RunningInstances)
    ec3.stop_instances(InstanceIds=RunningInstances)
    print('stopped your instances: ' + str(RunningInstances))
